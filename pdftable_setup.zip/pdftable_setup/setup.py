from distutils.core import setup

setup(name='pdftable', version='1.0', py_modules=['pdftable'],
      scripts=['pdftable'])
